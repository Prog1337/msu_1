#include <stdio.h>

int main(void) {
    int n;
    scanf("%d",&n);
    if (n%100>=65)
    {
        n=(n/100+1)*100;
        printf("%d",n);
        return 0;
    }
    if (n%20>15)
    {
        n=(((n/100)*100)+((n%100)/20+1)*30);
        printf("%d",n);
        return 0;
    }
    printf("%d",n);
    return 0;
}
