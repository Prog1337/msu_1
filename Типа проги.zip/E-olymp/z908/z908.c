#include <stdio.h>

int main(void) {
FILE* fin=NULL;
fin=fopen ("C:/Users/Aliya Shirali/Desktop/CODE", "r");
if (fin==NULL) { printf ("file ne otkrilsa\n"); return 1; }
return 0;
}
