#include <stdio.h>
#include <math.h>

int main(void) 
{
  int a;
  scanf ("%d", &a);
  while (a/10 >= 0)
  {
	  printf ("%d ", a%10);
	  a/=10;
	  if (a==0)
	  break;
  }
  return 0;
}
	  
