int is_prime(int k){
    printf("factors:\n", k);
    for(i = 1; i<=n; i++)
      if(n/i==0)
        printf("%d ",i);
}
