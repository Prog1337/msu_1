#include <stdio.h>
#include <stdlib.h>
int main(void) 
{
	FILE *fout=NULL;
	fout=fopen("input.txt", "w");
	int rand_a=1000000;
	for(int i=0;i<1000000;i++)
	{
		rand_a=1+rand()%2000000;
		fprintf(fout, "%d ", rand_a);
	}
	return 0;
}
