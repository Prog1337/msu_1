#include <stdio.h>
#include <math.h>
 
int f (int x, int y)
{
    if (x==0 || y==0)
    return 1;
    while (x!=0 && y!=0)
    {
        if (abs(x)>abs(y))
        x=abs(x) % abs(y);
        else
        y=abs(y) % abs(x);
    } 
    return x+y;
}
int main(void)
{
    int a, b, NOD;
    scanf ("%d %d", &a, &b);
    while (a==0 && b==0)
    {
        printf ("Error.Try again.\n");
        scanf ("%d%d", &a, &b);
    }
    NOD=f(a,b);
    printf ("NOD=%d\tNOK=%d\n", NOD, (abs(a)/NOD)*abs(b));
    return 0;
}
