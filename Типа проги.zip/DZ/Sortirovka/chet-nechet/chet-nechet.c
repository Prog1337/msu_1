#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void f (int* arr, int n)
{    
    int i=0, t=0, k=0;
    
    while (k==0)
    {
		k=1;
        for ( i=0; i+1<=n-1 ; i+=2)
        {
            if (arr[i]>arr[i+1])
            {    
                k=0;
                t=arr[i];
                arr[i]=arr[i+1];
                arr[i+1]=t;
			}
        }
        for ( i=1; i+1<=n-1 ; i+=2)
        {
            
            if (arr[i]>arr[i+1])
            {
                k=0;
                t=arr[i];
                arr[i]=arr[i+1];
                arr[i+1]=t;
            }
        }
	}
}

int main(void)
{
    int m=0, a=0, j=0;
    int *mas = (int*)malloc(sizeof(int) * m);
    FILE *fin=NULL;
    fin=fopen ("input.txt", "r");
    for ( m=0 ; fscanf (fin, "%d", &a)==1 ; m++ )
    mas[m]=a; 
    double t_full;
    t_full=clock();
    f(mas, m);
    t_full=clock()-t_full;
    t_full/=CLOCKS_PER_SEC;
    for ( j=0; j<=m-1 ; j++)
    {
        printf ("%d ", mas[j]);
    }
    printf("\naue\nTotal full time=%lg\n",t_full);
    return 0;
}
