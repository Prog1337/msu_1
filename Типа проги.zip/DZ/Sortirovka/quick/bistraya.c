#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void bistraya(int *arr, int n)
{
    int l=0, r=n-1, w=0, m=0;
    if(n<=1) 
    return;
    if(n==2) 
    if(arr[0]>arr[1])
    {
        w=arr[0];
        arr[0]=arr[1];
        arr[1]=w;
    }
    m=arr[(r+l)/2];
    while(l<=r)
    {
        while(arr[l]<m) 
        l++;
        while(arr[r]>m) 
        r--;
        if(l<=r)
        {
            w=arr[l];
            arr[l]=arr[r];
            arr[r]=w;
            l++;
            r--;
        }
    }
    if(r>0) 
    bistraya(&arr[0], r+1);
    if(l<n-1) 
    bistraya(&arr[l], n-l);
    return;
}
int main(void)
{
    FILE *fin=NULL, *fout=NULL;
    int *mas, k=0, i, t=0;
    double t_full;
    fin=fopen("input.txt", "r");
    fout=fopen("output.txt", "w");
    if (!fin)
    {
        printf ("Файл не открылся\n");
        return 1;
    }
    if (fscanf (fin, "%d", &k)!=1)
    {
        printf ("Файл пуст");
        return 2;
    }
    if (k<=0)
    {
        printf ("Массив не существует");
        return 3;
    }
    mas=(int*)malloc(k* (sizeof(int*)));
    for(i=0; i<k; i++)
    {
        fscanf (fin, "%d", &t);
        mas[i]=t;
    }
    t_full=clock();
    bistraya(mas, k);
    t_full=clock()-t_full;
    t_full/=CLOCKS_PER_SEC;
    for(i=0; i<k; i++)
    {
        fprintf(fout, "%d ", mas[i]);
    }
    printf ("Total full time=%lg\n", t_full);
    return 0;
}
 
