#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void f(int arr[], int n)
{
	FILE *A=NULL, *B=NULL, *C=NULL;
	int j=1, p=0, l=0;
	A=fopen("A.txt","w");
	fprintf(A,"%d ",arr[0]);
	B=fopen("B.txt","w");
	C=fopen("C.txt","w");
	while(j<n)
	{
		if(arr[j-1]<=arr[j])
		{
			fprintf(A,"%d ",arr[j]);
			j++;
		}
		else
		{
			l=j+1;
			break;
		}
		printf("j=%d\n",j);
	}
	while(l<n-1)
	{
		if(arr[l-1]<=arr[l])
		{
			fprintf(B,"%d ",arr[l]);
			l++;
		}
		else
		{
			p=l+1;
			break;
		}
		printf("l=%d\n",l);
	}
	while(p<n-1)
	{
		if(arr[p-1]<arr[p])
		{
			fprintf(C,"%d ",arr[p]);
			p++;
		}
		else
		break;
	}
	printf("p=%d\n",p);
}

int main(void)
{
	FILE *fin=NULL, *fout=NULL;
	int *mas=NULL, k=0, i=0;
	double t_full;
	fin=fopen("input.txt", "r");
	fout=fopen("output.txt", "w");
	if (!fin)
	{
		printf ("���� �� ������\n");
		return 1;
	}
	if (fscanf (fin, "%d", &k)!=1)
	{
		printf ("���� ����");
		return 2;
	}
	if (k<=0)
	{
		printf ("���ᨢ �� �������");
		return 3;
	}
    mas=(int*)malloc(k* (sizeof(int)));
    for(i=0; i<k; i++)
    {
		fscanf(fin, "%d", &mas[i]);
	}
	t_full=clock();
	f(mas, k);
	t_full=clock()-t_full;
	t_full/=CLOCKS_PER_SEC;
	for(i=0; i<k; i++)
	{
		fprintf(fout, "%d ", mas[i]);
	}
	printf ("��饥 �६�: %lg\n", t_full);
	return 0;
}
