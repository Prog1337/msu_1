#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void g(int a[], int m, int p)
{
	int w = 0, max = p, s1 = 2 * p + 1, s2 = 2 * p + 2;
	if (s1 < m && a[s1] > a[max])
		max = s1;
	if (s2 < m && a[s2] > a[max])
		max = s2;
	if (max != p)
	{
		w = a[p];
		a[p] = a[max];
		a[max] = w;
		g(a, m, max);
	}
}

void f(int arr[], int n)
{
	int v = 0;
	for (int j = n / 2 - 1; j >= 0; j--)
		g(arr, n, j);
	for (int j = n - 1; j > 0; j--)
	{
		v = arr[0];
		arr[0] = arr[j];
		arr[j] = v;
		g(arr, j, 0);
	}
}

int main(void)
{
	FILE *fin = NULL, *fout = NULL;
	int *mas = NULL, k = 0, i = 0;
	double t_full;
	fin = fopen("input.txt", "r");
	fout = fopen("output.txt", "w");
	if (!fin)
	{
		printf("Файл пуст\n");
		return 1;
	}
	if (fscanf(fin, "%d", &k) != 1)
	{
		printf("Ошибка");
		return 2;
	}
	if (k <= 0)
	{
		printf("Ошибка");
		return 3;
	}
	mas = (int *)malloc(k * (sizeof(int)));
	for (i = 0; i < k; i++)
	{
		fscanf(fin, "%d", &mas[i]);
	}
	t_full = clock();
	f(mas, k);
	t_full = clock() - t_full;
	t_full /= CLOCKS_PER_SEC;
	for (i = 0; i < k; i++)
	{
		fprintf(fout, "%d ", mas[i]);
	}
	printf("Время: %lg\n", t_full);
	return 0;
}
