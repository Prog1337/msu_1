#include <stdio.h>
#include <time.h>

void bitprint(unsigned m) 
{
	unsigned t=1<<31;
	int N=31, k=0;
	while(t!=0)
	{
		if(k<=((2<<m)-1) && N>0)
		{
			if(t&(m>>(31-N+k)))
			{
				printf("1");
			}
			else
			printf("0");
		}
		t>>=1;
		N--;
		k++;
	}
}

int main(void)
{
    int n;
    double t_full;
    printf("����� �᫮: ");
    scanf("%d", &n);
    t_full=clock();
    bitprint(n);
	t_full=clock()-t_full;
	t_full/=CLOCKS_PER_SEC;
    printf ("\n��饥 �६�: %lg\n", t_full);
    return 0;
}
