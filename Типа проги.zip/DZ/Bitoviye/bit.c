#include <stdio.h>
#include <time.h>

void PrintBit(int a) 
{
    int i=0;
    unsigned t = 1<<31;
    while(t!=0)
    {
    if(t&a)
    {
        printf("1");
        i++;
    }
    else
    printf("0");
    t=t>>1;
    }    
    printf("\n%u", a);
    printf("\n������⢮ ������: %d\n", i);
   
}

int main(void)
{
    unsigned b;
    double t_full;
    printf("����� �᫮: ");
    scanf("%u", &b);
    t_full=clock();
    PrintBit(b);
	t_full=clock()-t_full;
	t_full/=CLOCKS_PER_SEC;
    printf ("��饥 �६�: %lg\n", t_full);
    
    return 0;
}
