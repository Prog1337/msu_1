#include <stdio.h>
#include <time.h>

unsigned PrintBit_2(unsigned c)
{
	unsigned t = 1<<31;
	while(t!=0)
	{ 
		if(t&c)
		{
			t =~t;
			c&=t;
			return c;
		}		
	t=t>>1;  
	}
	return c;
}

void PrintBit(unsigned a) 
{
	int i=0;
	unsigned t = 1<<31;
	while(t!=0)
	{ 
	if(t&a)
	{ 
		printf("1");
		i++;
	}
	else
	printf("0");
	t=t>>1;  
	}
	printf("\n������⢮ ������: %d\n", i);
}

int main(void)
{
	unsigned b;
	double t_full;
    printf("����� �᫮: ");
    scanf("%u", &b);
    t_full=clock();
    PrintBit(b);
    PrintBit(PrintBit_2(b));
	t_full=clock()-t_full;
	t_full/=CLOCKS_PER_SEC;
    printf ("��饥 �६�: %lg\n", t_full);
	return 0;
}

