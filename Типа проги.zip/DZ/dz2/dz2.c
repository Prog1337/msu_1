#include <stdio.h>
#include <math.h>

int main (void) {
	int a, b, sum1, sum2=0;
	FILE* fin=NULL;
	fin=fopen ("input.txt","r");
	if (fin==NULL) {
		printf ("File didn't open");
		return 1;
		}
		if (fscanf (fin, "%d", &a)!=1) {
			printf ("File is empty");
			return 2;
			}
			
			while (fscanf (fin, "%d", &b)==1) {
				if (a>=0 && b>=0) {
					sum1 = sqrt (a*a+2*a*b+b*b);
					fscanf (fin, "%d", &a);
					a = 0;
				}
				if ((a>=0 && b<=0 && a+b>=0) || (a<=0 && b>=0 && a+b>=0)) {
					sum1 = sqrt (a*a-2*a*b+b*b);
					fscanf (fin, "%d", &a);
					a = 0;
				}
				if ((a>=0 && b<=0 && a+b<=0) || (a<=0 && b>=0 && a+b<=0)) {
					sum1 = - sqrt (a*a-2*a*b+b*b);
					fscanf (fin, "%d", &a);
					a = 0;
				}
				if (a<=0 && b<=0) {
					sum1 = - sqrt (a*a+2*a*b+b*b);
					fscanf (fin, "%d", &a);
					a = 0;
				}
				if (sum2 <= sum1) {
					sum2 = sum1;
				}
				else {
				sum1=sum1;
			}
		}
		if (sum2 >= sum1) {
			printf ("sum=%d", sum2);
		}
			if (sum2 < sum1) {
			printf ("sum=%d", sum1);
		}
			return 0;
		}
