#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void f(int n)
{    
    int *arr = malloc(sizeof(*arr) * n);
    int i=1, m=0, j=0, flag=0;
    arr[0]=2;
    arr[1]=3;
    if (n==1)
    printf ("2\n");
    if (n==2)
    printf ("3\n");
    for (j=1; i<n-1 ; j++)
    {
        flag=0;
        for(m=0; arr[m]*arr[m]<=6*j-1 ; m++)    
        { 
            if((6*j-1)%arr[m]==0)    
            {    
                flag++;
                break;
            }  
        }
        if (flag==0)
        {
            i++;
            arr[i]=6*j-1;
        }
        flag=0;
        for(m=0; arr[m]*arr[m]<=6*j+1 ; m++)    
        {    
            if((6*j+1)%arr[m]==0)      
            {   
                flag++;
                break;
            }  
        }
        if (flag==0)
        {
            i++;
            arr[i]=6*j+1;
        }
    }
    printf ("%d\n", arr[i]);
} 
int main(void)
{   
    int n=1000000;
    double t_full;
    t_full=clock();
    f(n);
    t_full=clock()-t_full;
    t_full/=CLOCKS_PER_SEC;
    printf("Total full time=%lg\n",t_full);
    return 0;
}
