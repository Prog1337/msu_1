#include <stdio.h>
#include <time.h>

void f(int k)
{    
	int i=5, j=2, m=5, t=0, id=0, a=1;
	while (i<=k)
	{
		id=0;
		a=1;
		t=6*j-1;
		for ( m=5; m*m<=t ; )
		{
			if (t%m==0)
			{
				id=1;
				break;
			}
			while ( a*a<=t )
			{
				a++;
				if (a%2==0)
				{
					m+=2;
					break;
				}
				if (a%2==1)
				{
					m+=4;
					break;
				}
			}
		}
		if (id==0)
		{
			if (i>=k)
			{
				printf ("t=%d\n", t);
				break;
			}
			i++;
		}
		
		id=0;
		a=1;
		t=6*j+1;
		for ( m=5; m*m<=t ; )
		{
			if (t%m==0)
			{
				id=1;
				break;
			}
			while ( a*a<=t )
			{
				a++;
				if (a%2==0)
				{
					m+=2;
					break;
				}
				if (a%2==1)
				{
					m+=4;
					break;
				}
			}
		}	
		if (id==0)
		{
			if (i>=k)
			{
				printf ("t=%d\n", t);
				break;
			}
			i++;
		}
		j++;
	}
}	

int main(void)
{   
	int n=1000000;
	double t_full;
	t_full=clock();
	f(n);
	t_full=clock()-t_full;
	t_full/=CLOCKS_PER_SEC;
	printf("Total full time=%lg\n",t_full);
	return 0;
}
