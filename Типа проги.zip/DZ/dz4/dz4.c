#include <stdio.h>
#define M 100
int f(int a[], long x, int n);

int main(void)
{
	long x;
	int n,i,k;// x - число, n - основание системы счисления, k - число цифр представления
	int a[M];
	FILE* fin=NULL;
	fin=fopen ("input.txt","r");
	if (!fin) {printf ("Файл не открылся\n"); return 1;}
	printf ("Введи число и основание:\n");
	scanf ("%ld%d", &x,&n);
	
	k=f(a,x,n);
	
	for (i=k-1; i>=0; i--)printf ("%d ", a[i]);
	printf ("\n");
	return 0;
}

    int f(int a[], long x, int n)
    {
		int j=0;
		if ( !x ) {a[0]=0; return 1;}
		for(j=0;x;j++)
		 {
			 a[j]=x%n;
			 x/=n;
		 }
		 return j;
	 }

