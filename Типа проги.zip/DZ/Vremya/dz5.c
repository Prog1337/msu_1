#include <stdio.h>
#include <time.h>

int f(void)
{
	int i;
	for (i=1; i>0; i++);
	return i;
}
	
int main (void)
{
	int k; 
	double t_full;
	
	t_full=clock();// 2) клок как щелчок секундомера здесь засекаем во сколько начали
	k=f(); // 1) чтобы выяснить как быстор работает функция , засекаем время
	t_full=clock()-t_full; // 3) время конца вычитаем время начала продложительность 
	t_full/=CLOCKS_PER_SEC; // 4) время хранится в спецю виде ( не секунды)
	printf ("Total full time=%lg,\n", t_full);
	printf ("k-1=%d\n", k-1);
	return 0;
}
