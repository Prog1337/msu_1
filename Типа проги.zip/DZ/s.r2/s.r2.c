void funkciya(int m, int *b)
{int t, j=0, k=0;

 for(j=0;j<m;j++)
 {
  if(b[j]%3!=0)
  {
 t = b[k];
 b[k]=b[j];
 b[j] = t;
 k++;
 }
 }
return;
}

int main(void) 
{
  int n, i=0;
  int *a;//указатель на ячейку памяти
  scanf ("%d", &n);
  a = (int*)malloc(n*sizeof(int));//резервируем память для массива
  for(i=0; i<n; i++)
 scanf("%d", &a[i]);//заполняем массив
  funkciya(n, a);//вызываем функцию. Там массив как-то обрабатывается/изменяется. По завершению работы функции имеем новый массив
  for(i=0; i<n; i++)
 printf("%d ", a[i]);//печатаем массив
  return 0;
}
