#include <stdio.h>
#include <math.h>

int main (void) {
	int a, b, sum1, sum2=0;
	FILE* fin=NULL;
	fin=fopen ("input.txt","r");
	if (fin==NULL) {
		printf ("File didn't open");
		return 1;
		}
		if (fscanf (fin, "%d", &a)!=1) {
			printf ("File is empty");
			return 2;
			}
			
			while (fscanf (fin, "%d", &b)==1) {
				if (b>a && a>b && a+b>0) {
					sum1 = a+b;
					sum2 = sum1;
					fscanf (fin, "%d", &a);
					}
					if (a<0 && b<0) {
						a=0, b=0;
						sum2=0;
						}
						if ((b<0 || a<0) && a+b>=0) {
							sum2 = b+a;
							fscanf (fin, "%d", &a);
							}
							else {
								fscanf (fin, "%d", &a);
								}
								}
								printf ("%d", sum2);
								return 0;
								}
