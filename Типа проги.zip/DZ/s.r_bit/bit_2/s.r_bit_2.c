#include <stdio.h>

void bitprint(int m)
{
	unsigned t=1<<31;
	while(t!=0)
	{
		if(t&m)
		{
			printf("1");
		}
		else
		printf("0");
		t>>=1;
	}
	return;
}

int main(void)
{
	int n;
	scanf("%u",&n);
	bitprint(n);
	return 0;
}

