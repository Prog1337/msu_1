#include <stdio.h>

void bitprint (int m)
{
	unsigned i=1<<31, j=1<<30;
	int t=0;
	while(i!=0 && j!=0)
	{
		if(i&m && j&m)
		t++;
		i>>=1;
		j>>=1;
	}
	printf("%d\n",t);
	return;
}

int main(void)
{
	int n;
	scanf("%d",&n);
	bitprint(n);
	return 0;
}
