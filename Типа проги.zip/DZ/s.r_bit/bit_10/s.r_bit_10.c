#include <stdio.h>

void bitprint (int m, int j, int b)
{
	if((((m&(1<<j))==1)&&((m&(1<<b))==1))||(((m|(1<<j))==0)&&((m|(1<<b))==0))||(j==b))
	printf("%d\n",m);
	else
	printf("%d\n",(int)(m^((1<<j)|(1<<b))));
	return;
}

int main(void)
{
	int n, i, a;
	scanf("%d%d%d",&n,&i,&a);
	bitprint(n,i,a);
	return 0;
}
