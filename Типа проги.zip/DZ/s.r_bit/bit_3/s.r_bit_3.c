#include <stdio.h>

void bitprint(int m)
{
	unsigned t=1<<31;
	int i=0;
	while(t!=0)
	{
		if(t&m)
		{
			printf("1");
			i++;
		}
		else
		printf("0");
		t=t>>1;
	}
	printf("\n������⢮ ������: %d",i);
}

int main(void)
{
	int n;
	scanf("%u",&n);
	bitprint(n);
	return 0;
}
