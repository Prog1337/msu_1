#include <stdio.h>

void bitprint (int m, int j)
{
	printf("%d\n",(int)(m^(1<<j)));
	return;
}

int main(void)
{
	int n, i;
	scanf("%d%d",&n,&i);
	bitprint(n, i);
	return 0;
}
