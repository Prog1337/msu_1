#include <stdio.h>

void bitprint(int m)
{
	printf("%d", 1<<m);
	return;
}

int main(void)
{
	int n;
	scanf("%d",&n);
	bitprint(n);
	return 0;
}
