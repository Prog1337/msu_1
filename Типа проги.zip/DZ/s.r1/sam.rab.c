#include <stdio.h>
int main (void)
{
    int a, b, i=1, max_i=1;
    FILE* fin=NULL;
    fin=fopen ("input.txt","r");
    if (fin==NULL) {
        printf ("File did not open");
        return 1;
        }
        if (fscanf (fin,"%d", &a)!=1) {
            printf ("File is empty");
            return 2;
            }
            
            while (fscanf (fin, "%d", &b)==1) {
                if (b>a)
                i++;
                else {
                    if (i>max_i)
                    max_i=i;
                    i=1;
                }
                a=b;
            }
            if (i>max_i)
                    max_i=i;
            printf ("%d", max_i);
            return 0;
        }
//В данной реализации программы подразумевается ,что 1 элемент тоже составляет последовательность
